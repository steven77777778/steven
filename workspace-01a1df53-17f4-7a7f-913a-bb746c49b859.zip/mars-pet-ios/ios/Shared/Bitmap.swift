import SwiftUI
import UIKit

/// 讀取套件裡的 32-bit BGRA 透明 BMP 像素圖（同時相容根目錄與 Sprites/ 子目錄結構）。
public func bmp(_ name: String) -> Image {
    if let image = UIImage(named: "\(name).bmp") {
        return Image(uiImage: image)
    }
    if let image = UIImage(named: "Sprites/\(name).bmp") {
        return Image(uiImage: image)
    }
    if let path = Bundle.main.path(forResource: name, ofType: "bmp", inDirectory: "Sprites")
        ?? Bundle.main.path(forResource: name, ofType: "bmp"),
       let image = UIImage(contentsOfFile: path) {
        return Image(uiImage: image)
    }
    return Image(systemName: "sparkles")
}
