import AppIntents
import SwiftUI
import WidgetKit

private let playKey = "mars_play_idx"
private let untilKey = "mars_play_until"

/// ヨルシカ「火星人」高精細 96×108 純色像素：全 12 組 MV 連續動畫（每組 8 格原生像素，桌面小工具零文字純淨版！）
enum MarsWidgetAction: String, CaseIterable, AppEnum {
    case idle
    case bat
    case bubble
    case paint
    case sparkle
    case smash
    case piano
    case point
    case read
    case pingpong
    case cafe
    case flare

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "預設互動模式"
    static var caseDisplayRepresentations: [MarsWidgetAction: DisplayRepresentation] = [
        .idle:     "輪流播放全部 11 組 MV 名場面（推薦）",
        .bat:      "固定動作：#01/#59 球棒擊破紅墨",
        .bubble:   "固定動作：#08-#11 側身吹大紅泡泡",
        .paint:    "固定動作：#15-#24 揮灑綠藍彩墨與粉紅水珠",
        .sparkle:  "固定動作：#25-#26 三指與掌心閃星",
        .smash:    "固定動作：#27-#35 紅色長棍重砸",
        .piano:    "固定動作：#36-#37 黑西裝深夜彈琴",
        .point:    "固定動作：#42-#46 抱頭抓狂後指你",
        .read:     "固定動作：#47-#48 托腮讀書望向陽光",
        .pingpong: "固定動作：#51-#52 胸前顛乒乓球",
        .cafe:     "固定動作：#54 土耳其紅帽圓墨鏡喝熱咖啡",
        .flare:    "固定動作：#65-#78 星空信號槍與無重力煙火"
    ]

    var cycleDuration: Double {
        switch self {
        case .idle:     return 1.50
        case .bat:      return 0.96
        case .bubble:   return 1.28
        case .paint:    return 1.08
        case .sparkle:  return 1.08
        case .smash:    return 1.00
        case .piano:    return 1.15
        case .point:    return 1.12
        case .read:     return 1.36
        case .pingpong: return 0.96
        case .cafe:     return 1.32
        case .flare:    return 1.16
        }
    }

    var holdSeconds: Double {
        switch self {
        case .idle:     return 0
        case .bubble, .cafe, .flare:
                        return 4.0
        default:        return 3.4
        }
    }

    var frameNames: [String] {
        (0..<8).map { "pet-\(rawValue)-\($0)" }
    }

    static let tapRotation: [MarsWidgetAction] = [
        .bat, .bubble, .paint, .sparkle, .smash,
        .piano, .point, .read, .pingpong, .cafe, .flare
    ]
}

/// 點擊桌面小工具時執行：切換下一個 MV 名場面動作，播完自動切回 24 小時待機呼吸
struct WaveWidgetIntent: AppIntent {
    static var title: LocalizedStringResource = "和火星人互動"

    func perform() async throws -> some IntentResult {
        let defaults = UserDefaults.standard
        let next = defaults.integer(forKey: playKey) + 1
        defaults.set(next, forKey: playKey)
        let action = MarsWidgetAction.tapRotation[next % MarsWidgetAction.tapRotation.count]
        defaults.set(Date().addingTimeInterval(action.holdSeconds).timeIntervalSince1970, forKey: untilKey)
        return .result()
    }
}

/// 小工具背景與 iPhone 17 液態玻璃風格設定（長按小工具 → 編輯小工具）
enum PetBackdropStyle: String, AppEnum {
    case liquidGlass
    case marsDuskGlass
    case clearSystem
    case topLeft, topRight, midLeft, midRight, bottomLeft, bottomRight

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "小工具風格與背景"
    static var caseDisplayRepresentations: [PetBackdropStyle: DisplayRepresentation] = [
        .liquidGlass:   "iOS 26 清透液態玻璃（推薦 iPhone 17）",
        .marsDuskGlass: "火星暮光液態玻璃（MV 星空紅韻）",
        .clearSystem:   "系統原生透明玻璃",
        .topLeft:       "偽透明桌布：左上",
        .topRight:      "偽透明桌布：右上",
        .midLeft:       "偽透明桌布：左中",
        .midRight:      "偽透明桌布：右中",
        .bottomLeft:    "偽透明桌布：左下",
        .bottomRight:   "偽透明桌布：右下"
    ]

    var isWallpaperSlice: Bool {
        switch self {
        case .topLeft, .topRight, .midLeft, .midRight, .bottomLeft, .bottomRight:
            return true
        default:
            return false
        }
    }
}

struct PetWidgetConfig: WidgetConfigurationIntent {
    static var title: LocalizedStringResource = "火星人桌寵"
    static var description = IntentDescription("純淨零文字桌面寵物！24 小時呼吸搖擺，點一下輪播 12 組 MV 名場面。")

    @Parameter(title: "風格與位置", default: .liquidGlass)
    var style: PetBackdropStyle

    @Parameter(title: "點擊動作偏好", default: .idle)
    var pinnedAction: MarsWidgetAction

    @Parameter(title: "揮棒／重砸時敲碎液態玻璃", default: true)
    var shatterGlass: Bool
}

struct PetEntry: TimelineEntry {
    let date: Date
    let action: MarsWidgetAction
    let style: PetBackdropStyle
    let shatterGlass: Bool
    let crackedAftermathBy: MarsWidgetAction?
}

struct PetProvider: AppIntentTimelineProvider {
    func placeholder(in context: Context) -> PetEntry {
        PetEntry(date: .now, action: .idle, style: .liquidGlass, shatterGlass: true, crackedAftermathBy: nil)
    }

    func snapshot(for configuration: PetWidgetConfig, in context: Context) async -> PetEntry {
        let previewAct = configuration.pinnedAction == .idle ? .bubble : configuration.pinnedAction
        return PetEntry(
            date: .now,
            action: previewAct,
            style: configuration.style,
            shatterGlass: configuration.shatterGlass,
            crackedAftermathBy: nil
        )
    }

    func timeline(for configuration: PetWidgetConfig, in context: Context) async -> Timeline<PetEntry> {
        let defaults = UserDefaults.standard
        let now = Date()
        let until = Date(timeIntervalSince1970: defaults.double(forKey: untilKey))

        var entries: [PetEntry] = []
        if now < until {
            let act: MarsWidgetAction
            if configuration.pinnedAction != .idle {
                act = configuration.pinnedAction
            } else {
                let idx = defaults.integer(forKey: playKey)
                act = MarsWidgetAction.tapRotation[idx % MarsWidgetAction.tapRotation.count]
            }
            let breaksGlass = configuration.shatterGlass && (act == .bat || act == .smash)

            entries.append(PetEntry(
                date: now,
                action: act,
                style: configuration.style,
                shatterGlass: configuration.shatterGlass,
                crackedAftermathBy: nil
            ))

            if breaksGlass {
                let healTime = until.addingTimeInterval(3.5)
                entries.append(PetEntry(
                    date: until,
                    action: .idle,
                    style: configuration.style,
                    shatterGlass: configuration.shatterGlass,
                    crackedAftermathBy: act
                ))
                entries.append(PetEntry(
                    date: healTime,
                    action: .idle,
                    style: configuration.style,
                    shatterGlass: configuration.shatterGlass,
                    crackedAftermathBy: nil
                ))
            } else {
                entries.append(PetEntry(
                    date: until,
                    action: .idle,
                    style: configuration.style,
                    shatterGlass: configuration.shatterGlass,
                    crackedAftermathBy: nil
                ))
                entries.append(PetEntry(
                    date: until.addingTimeInterval(1.2),
                    action: .idle,
                    style: configuration.style,
                    shatterGlass: configuration.shatterGlass,
                    crackedAftermathBy: nil
                ))
            }
        } else {
            entries.append(PetEntry(
                date: now,
                action: .idle,
                style: configuration.style,
                shatterGlass: configuration.shatterGlass,
                crackedAftermathBy: nil
            ))
        }
        return Timeline(entries: entries, policy: .never)
    }
}

struct PetWidgetView: View {
    let entry: PetEntry
    @Environment(\.widgetFamily) private var family
    @Environment(\.widgetRenderingMode) private var renderingMode

    private func impactPoint(for act: MarsWidgetAction) -> UnitPoint {
        if family == .systemMedium {
            return act == .smash ? UnitPoint(x: 0.62, y: 0.74) : UnitPoint(x: 0.61, y: 0.44)
        } else {
            return act == .smash ? UnitPoint(x: 0.74, y: 0.74) : UnitPoint(x: 0.73, y: 0.44)
        }
    }

    var body: some View {
        Button(intent: WaveWidgetIntent()) {
            ZStack {
                backdropContent

                // 1×1 與 2×1 皆為 100% 零文字純淨桌面寵物！（無任何標籤框或文字框干擾）
                petStage

                if entry.shatterGlass && renderingMode == .fullColor {
                    if entry.action == .bat || entry.action == .smash {
                        ClockSyncedGlassShatter(
                            cycleDuration: entry.action.cycleDuration,
                            impactOrigin: impactPoint(for: entry.action)
                        )
                    } else if let brokenBy = entry.crackedAftermathBy {
                        ShatteredLiquidGlassOverlay(
                            impactOrigin: impactPoint(for: brokenBy),
                            intenseFlash: false
                        )
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .buttonStyle(.plain)
        .unredacted()
        .containerBackground(for: .widget) {
            containerBg
        }
    }

    private var petStage: some View {
        ZStack {
            VStack {
                Spacer()
                Ellipse()
                    .fill(.black.opacity(entry.style.isWallpaperSlice ? 0.16 : 0.24))
                    .frame(width: family == .systemMedium ? 68 : 60, height: 9)
                    .blur(radius: 2)
                    .padding(.bottom, 10)
            }

            PixelAnimatedWidgetSprite(
                frameNames: entry.action.frameNames,
                cycleDuration: entry.action.cycleDuration
            )
            .padding(.vertical, 6)
            .padding(.horizontal, family == .systemMedium ? 24 : 6)
        }
    }

    @ViewBuilder
    private var backdropContent: some View {
        if entry.style.isWallpaperSlice {
            bmp("bg-\(entry.style.rawValue)")
                .resizable()
                .scaledToFill()
        } else if entry.style == .marsDuskGlass || entry.action == .flare || entry.action == .piano {
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.12, green: 0.12, blue: 0.23).opacity(0.80),
                        Color(red: 0.34, green: 0.14, blue: 0.22).opacity(0.70)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                ContainerRelativeShape()
                    .strokeBorder(
                        LinearGradient(
                            colors: [.white.opacity(0.45), .white.opacity(0.06), Color(red: 0.95, green: 0.45, blue: 0.48).opacity(0.32)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 1.2
                    )
            }
        } else if entry.style == .liquidGlass {
            ZStack {
                LinearGradient(
                    colors: [
                        .white.opacity(0.14),
                        .white.opacity(0.02),
                        Color(red: 0.88, green: 0.30, blue: 0.34).opacity(0.08)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                ContainerRelativeShape()
                    .strokeBorder(
                        LinearGradient(
                            colors: [.white.opacity(0.50), .white.opacity(0.08), .white.opacity(0.28)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 1.1
                    )
            }
        } else {
            Color.clear
        }
    }

    @ViewBuilder
    private var containerBg: some View {
        if entry.style.isWallpaperSlice {
            bmp("bg-\(entry.style.rawValue)")
                .resizable()
                .scaledToFill()
        } else if entry.style == .clearSystem {
            Color.clear
        } else {
            Rectangle().fill(.ultraThinMaterial)
        }
    }
}

struct PetWidget: Widget {
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: "PetWidget", intent: PetWidgetConfig.self, provider: PetProvider()) { entry in
            PetWidgetView(entry: entry)
        }
        .configurationDisplayName("火星人桌寵")
        .description("純淨零文字桌面寵物！24 小時呼吸搖擺，點一下輪流重現《火星人》MV 全 12 組經典動作。")
        .supportedFamilies([.systemSmall, .systemMedium])
        .contentMarginsDisabled()
    }
}
